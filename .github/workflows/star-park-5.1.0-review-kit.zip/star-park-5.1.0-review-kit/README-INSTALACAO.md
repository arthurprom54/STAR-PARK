# STAR PARK 5.1.0 — pacote de revisão segura

A integração de escrita usada nesta conversa recusou a criação de branch no GitHub com erro 403. Portanto, o pacote não afirma que alterou o repositório nem que criou um PR.

## O que o pacote faz

- `tooling/patch-5-1-0-workflow.py`: corrige o instalador de atualização já existente, usando marcadores exatos e interrompendo se encontrar trecho ausente ou duplicado.
- `.github/workflows/prepare-star-park-5-1.yml`: executa o reparador no branch de um PR e grava a correção somente nesse mesmo branch, caso a permissão `contents: write` esteja habilitada.

O reparador corrige o botão **Encerrar meta** que fazia falhar o teste, registra a preferência opcional de conta na candidatura, mostra essa preferência à administração, converte contas antigas `MODERATOR` em `ADMIN` com auditoria (sem tocar na conta `OWNER`), limita os papéis operacionais a `MEMBER` e `ADMIN`, cria nomes de branch exclusivos, deixa falhas de PR visíveis e permite revalidar instalações já em 5.1.0.

O instalador principal já existente no repositório prepara também a prévia de tag Brawl Stars, o estado `AWAITING_WHATSAPP`, o link e a confirmação manual antes da ativação, login por usuário/e-mail, senha de 6 a 128 caracteres, perfil personalizado, cancelamento de inscrições, metas coletivas, conquistas, linha do tempo, notificações e monitoramento.

## Como usar sem tocar na `main`

1. No GitHub, crie um branch a partir de `main`, por exemplo `star-park/preparar-5-1-0`.
2. Nesse branch, envie estes dois arquivos mantendo os caminhos:
   - `tooling/patch-5-1-0-workflow.py`
   - `.github/workflows/prepare-star-park-5-1.yml`
3. Abra um Pull Request desse branch para `main`, mas **não faça merge**.
4. O workflow auxiliar deve executar sozinho, validar o reparador e corrigir o instalador somente no branch do PR.
5. Quando o workflow auxiliar terminar com sucesso, abra **Actions → STAR PARK - Grande Atualizacao Segura**. Selecione o branch `star-park/preparar-5-1-0` na opção de branch e execute `workflow_dispatch`, mantendo `criar_pull_request` ativado.
6. O workflow principal fará o backup, aplicará o conjunto da atualização, executará `npm test` e tentará abrir uma PR separada para revisar o código 5.1.0.
7. Revise os checks e o diff da PR gerada. Não aprove merge nem deploy sem conferir tudo.

## Cuidados

- O workflow auxiliar precisa de permissão de `GITHUB_TOKEN` para gravar conteúdo (`contents: write`) no branch de PR da mesma origem. Se a política do repositório bloquear essa permissão, ele falhará sem modificar `main`; nesse caso, execute o reparador manualmente em uma cópia local.
- O workflow principal guarda backup do código-fonte antes da aplicação e executa testes antes de criar/atualizar a PR.
- A migração `MODERATOR` → `ADMIN` acontece na inicialização da nova versão e registra auditoria no armazenamento da aplicação. O backup prévio é importante para recuperação.
- Não foi possível executar `npm test` contra uma cópia completa do repositório nesta sessão: a conexão GitHub recusou a criação de branch com erro 403. O reparador passou na verificação sintática Python e foi executado com sucesso em um cenário de teste isolado; os marcadores foram comparados com os arquivos atuais do repositório.
- Nenhum software pode ser garantido como impossível de falhar. O pacote utiliza verificações explícitas e exige a suíte do projeto antes da PR de atualização.
